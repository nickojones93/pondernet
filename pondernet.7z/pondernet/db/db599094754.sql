-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 24-11-2015 a las 09:12:59
-- Versión del servidor: 5.6.26
-- Versión de PHP: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db599094754`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE PROCEDURE `proc_act_caja_1`()
BEGIN
	DECLARE vPRIMER_USUARIO INT(11) DEFAULT 0;

	/*PASAR A LA CAJA 1 A TODOS LOS QUE TENGAN 1 COMPRA Y DOS VENTAS*/
  INSERT INTO `caja_1` (ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, 0
		FROM `usuarios_compras_ventas`
		WHERE
			COMPRAS > 0 AND VENTAS > 1
			AND ID_USUARIO NOT IN (SELECT ID_USUARIO FROM `caja_1`);
	
	/*TOMAR EL PRIMER USUARIO EN ENTRAR A LA CAJA 1*/
	SELECT ID_USUARIO INTO vPRIMER_USUARIO FROM `caja_1` ORDER BY FECHA LIMIT 1;
	
	/*REGISTRAR EN EL CIRCUITO DEL PRIMER USUARIO A LOS USUARIOS DE LA CAJA 1 QUE NO FUERON INVITADOS POR NADIE*/
	INSERT INTO `caja_1` (ID_USUARIO, ID_INVITADO)
		SELECT vPRIMER_USUARIO, ID_USUARIO
		FROM `caja_1` C
		WHERE
			(SELECT COALESCE(REFERIDO_POR, 0) FROM `user` WHERE ID = C.ID_USUARIO) = 0
			AND (vPRIMER_USUARIO, ID_USUARIO) NOT IN (SELECT ID_USUARIO, ID_INVITADO FROM `caja_1`)
      AND vPRIMER_USUARIO <> ID_USUARIO;
	
	/*REGISTRAR EN LOS CIRCUITOS DE CADA USUARIO A SUS INVITADOS QUE HAYAN PASADO A LA CAJA 1*/
	INSERT INTO `caja_1` (ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, ID_INVITADO
		FROM `usuario_invitado`
		WHERE
			ID_USUARIO IN (SELECT ID_USUARIO FROM `caja_1`)
			AND ID_INVITADO IN (SELECT ID_USUARIO FROM `caja_1`)
			AND ID_INVITADO NOT IN (SELECT ID_INVITADO FROM `caja_1`);
			
  /*AUTOMATICAMENTE ASIGNAR ROL 'REVISOR' A LOS USUARIOS CON 1 COMPRA Y 2 VENTAS QUE AUN NO LO TENGAN*/
  UPDATE `user` SET ROL_ID = 2 WHERE ROL_ID = 1 AND ID IN (SELECT ID_USUARIO FROM `caja_1`);
END$$

CREATE PROCEDURE `proc_act_caja_2`()
BEGIN
	/*PASAR A LA CAJA 2 A LOS USUARIOS DE LA 1 QUE TENGAN MAS DE 2 INVITADOS EN LA 1*/
	INSERT INTO `caja_2`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, 0
		FROM `usuarios_caja_1`
		WHERE
			INVITADOS > 2
			AND ID_USUARIO NOT IN (SELECT ID_USUARIO FROM `caja_2`);
	
	/*ACTUALIZAR LOS CIRCUITOS DE LA CAJA 2 CON LOS INVITADOS DE LA CAJA 1 QUE COMPLETARON 2 VENTAS*/
	INSERT INTO `caja_2`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, ID_INVITADO
		FROM `caja_1`C
		WHERE
			(SELECT INVITADOS FROM `usuarios_caja_1` WHERE ID_USUARIO = C.ID_USUARIO) > 2
			AND (SELECT INVITADOS FROM `usuarios_caja_1` WHERE ID_USUARIO = C.ID_INVITADO) > 2
			AND (ID_USUARIO, ID_INVITADO) NOT IN (SELECT ID_USUARIO, ID_INVITADO FROM `caja_2`);
			
END$$

CREATE PROCEDURE `proc_act_caja_3`()
BEGIN
  INSERT INTO `caja_3`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, 0
		FROM `usuarios_caja_2`
		WHERE
			INVITADOS > 2
			AND ID_USUARIO NOT IN (SELECT ID_USUARIO FROM `caja_3`);

	/*INSERT INTO `caja_3`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, ID_INVITADO
		FROM USUARIO_INVITADO
		WHERE
			ID_USUARIO IN (SELECT ID_USUARIO FROM `caja_3`)
			AND ID_INVITADO IN (SELECT ID_USUARIO FROM `caja_3`)
			AND (ID_USUARIO, ID_INVITADO) NOT IN (SELECT ID_USUARIO, ID_INVITADO FROM `caja_3`);*/
	INSERT INTO `caja_3`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, ID_INVITADO
		FROM `caja_2` C
		WHERE
			(SELECT INVITADOS FROM `usuarios_caja_2` WHERE ID_USUARIO = C.ID_USUARIO) > 2
			AND (SELECT INVITADOS FROM `usuarios_caja_2` WHERE ID_USUARIO = C.ID_INVITADO) > 2
			AND (ID_USUARIO, ID_INVITADO) NOT IN (SELECT ID_USUARIO, ID_INVITADO FROM `caja_3`);
  
END$$

CREATE PROCEDURE `proc_act_caja_4`()
BEGIN
  INSERT INTO `caja_4`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, 0
		FROM `usuarios_caja_3`
		WHERE
			INVITADOS > 2
			AND ID_USUARIO NOT IN (SELECT ID_USUARIO FROM `caja_4`);

	INSERT INTO `caja_4`(ID_USUARIO, ID_INVITADO)
		SELECT ID_USUARIO, ID_INVITADO
		FROM `caja_3`C
		WHERE
			(SELECT INVITADOS FROM `usuarios_caja_3` WHERE ID_USUARIO = C.ID_USUARIO) > 2
			AND (SELECT INVITADOS FROM `usuarios_caja_3` WHERE ID_USUARIO = C.ID_INVITADO) > 2
			AND (ID_USUARIO, ID_INVITADO) NOT IN (SELECT ID_USUARIO, ID_INVITADO FROM `caja_4`);
  
END$$

CREATE PROCEDURE `proc_act_caja_5`()
BEGIN
  INSERT INTO `caja_5`(ID_USUARIO)
		SELECT ID_USUARIO
		FROM `usuarios_caja_4`
		WHERE
			INVITADOS > 2
			AND ID_USUARIO NOT IN (SELECT ID_USUARIO FROM `caja_5`);
END$$

CREATE PROCEDURE `proc_cobrar_circuito`(IN pUSER_ID INT, IN pSEGUIR INT, INOUT pRES INT)
BEGIN
  DECLARE VALOR_CURSO INT DEFAULT 0;
  DECLARE EXISTE INT(1) DEFAULT 0;
	DECLARE COMISIONES INT DEFAULT 0;
  
	SET pRES = 0;
  
  SELECT 1 INTO EXISTE FROM `caja_5` WHERE ID_USUARIO = pUSER_ID;
  IF COALESCE(EXISTE, 0) = 1 THEN
		SELECT SUM(COMISION) INTO COMISIONES FROM `curso_abonado` WHERE REFERIDO_POR = pUSER_ID AND BONO_SOLIC <> 1;
		IF COMISIONES > 49 THEN	
			INSERT INTO `pagos` (ID_USUARIO, CANTIDAD, TIPO, PAGADO) VALUES (pUSER_ID, COMISIONES, 1, 0);
		END IF;
		UPDATE `curso_abonado` SET ACTIVO = 0 WHERE REFERIDO_POR = pUSER_ID AND ACTIVO = 1;
		DELETE FROM `caja_2`WHERE ID_USUARIO = pUSER_ID;
		DELETE FROM `caja_3`WHERE ID_USUARIO = pUSER_ID;
		DELETE FROM `caja_4`WHERE ID_USUARIO = pUSER_ID;
		DELETE FROM `caja_5`WHERE ID_USUARIO = pUSER_ID;
		
    IF pSEGUIR = 1 THEN
			DELETE FROM `caja_1`WHERE ID_USUARIO = pUSER_ID AND ID_INVITADO <> 0;
      SELECT PRECIO INTO VALOR_CURSO FROM `producto` LIMIT 1;
      /*UPDATE USER SET
				CREDITO_COMISIONES = CREDITO_COMISIONES + COMISIONES ,
				CREDITO_CIRCUITOS = CREDITO_CIRCUITOS + (3000 - VALOR_CURSO)
				WHERE ID = pUSER_ID;*/
			INSERT INTO `pagos` (ID_USUARIO, CANTIDAD, TIPO, PAGADO) VALUES (pUSER_ID, 3000 - VALOR_CURSO, 2, 0);
      SET pRES = 1;
    ELSE
			DELETE FROM `caja_1`WHERE ID_USUARIO = pUSER_ID;
      /*UPDATE USER SET
				CREDITO_COMISIONES = CREDITO_COMISIONES + COMISIONES ,
				CREDITO_CIRCUITOS = CREDITO_CIRCUITOS + 3000
				WHERE ID = pUSER_ID;*/
      INSERT INTO `pagos` (ID_USUARIO, CANTIDAD, TIPO, PAGADO) VALUES (pUSER_ID, 3000, 2, 0);
	  DELETE FROM `user_historial` WHERE ID = pUSER_ID;
      INSERT INTO `user_historial` SELECT * FROM `user` WHERE ID = pUSER_ID;
      DELETE FROM `user` WHERE ID = pUSER_ID;
      SET pRES = 1;
    END IF;
		
  ELSE
    SET pRES = -1;
  END IF;
  
END$$

CREATE PROCEDURE `proc_cobrar_comisiones`(IN `pUSER_ID` int)
BEGIN
	DECLARE vCOMISIONES INT(11) DEFAULT 0;
	
	SELECT SUM(COMISION) INTO vCOMISIONES FROM `curso_abonado` WHERE REFERIDO_POR = pUSER_ID AND BONO_SOLIC <> 1 AND ACTIVO = 1;
	IF vCOMISIONES > 49 THEN	
		INSERT INTO `pagos` (ID_USUARIO, CANTIDAD, TIPO, PAGADO) VALUES (pUSER_ID, vCOMISIONES, 1, 0);
		UPDATE `curso_abonado` SET BONO_SOLIC = 1 WHERE REFERIDO_POR = pUSER_ID AND ACTIVO = 1;
		#UPDATE USER SET CREDITO_COMISIONES = COALESCE(CREDITO_COMISIONES, 0) + vCOMISIONES WHERE ID = pUSER_ID;
	END IF;
END$$

CREATE PROCEDURE `proc_ins_caja_1`(IN `pID_USUARIO` INT, IN `pID_INVITADO` INT)
BEGIN
  DECLARE vEXISTE INT(1) DEFAULT NULL;
  
  SELECT 1 INTO vEXISTE FROM `caja_1`WHERE ID_USUARIO = pID_USUARIO AND ID_INVITADO = pID_INVITADO LIMIT 1;
  IF ISNULL(vEXISTE) THEN
    INSERT INTO `caja_1`(ID_USUARIO, ID_INVITADO) VALUES (pID_USUARIO, pID_INVITADO);
    UPDATE `user` SET ROL_ID = 2 WHERE ID = pID_USUARIO AND ROL_ID = 1;
  END IF;
  
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `app_config`
--

CREATE TABLE IF NOT EXISTS `app_config` (
  `id` bigint(20) unsigned NOT NULL,
  `activar_log` bit(1) NOT NULL DEFAULT b'1',
  `cuenta_paypal` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `app_config`
--

INSERT INTO `app_config` (`id`, `activar_log`, `cuenta_paypal`) VALUES
(1, b'0', 'paypal@pondernet.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `auditoria`
--

CREATE TABLE IF NOT EXISTS `auditoria` (
  `id` bigint(20) unsigned NOT NULL,
  `operacion` varchar(250) DEFAULT NULL,
  `autor` varchar(50) NOT NULL,
  `producto` varchar(250) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ip` varchar(25) NOT NULL,
  `detalles` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Disparadores `auditoria`
--
DELIMITER $$
CREATE TRIGGER `tr_audit_ip_local` BEFORE INSERT ON `auditoria`
 FOR EACH ROW IF NEW.IP = '::1' THEN
	SET NEW.IP = '127.0.0.1';
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_1`
--

CREATE TABLE IF NOT EXISTS `caja_1` (
  `id_usuario` int(11) NOT NULL,
  `id_invitado` int(11) NOT NULL DEFAULT '0',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Disparadores `caja_1`
--
DELIMITER $$
CREATE TRIGGER `tr_caja_1` AFTER INSERT ON `caja_1`
 FOR EACH ROW BEGIN
  DECLARE PP INT(1);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_2`
--

CREATE TABLE IF NOT EXISTS `caja_2` (
  `id_usuario` int(11) NOT NULL,
  `id_invitado` int(11) NOT NULL DEFAULT '0',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_3`
--

CREATE TABLE IF NOT EXISTS `caja_3` (
  `id_usuario` int(11) NOT NULL,
  `id_invitado` int(11) NOT NULL DEFAULT '0',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_4`
--

CREATE TABLE IF NOT EXISTS `caja_4` (
  `id_usuario` int(11) NOT NULL,
  `id_invitado` int(11) NOT NULL DEFAULT '0',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `caja_5`
--

CREATE TABLE IF NOT EXISTS `caja_5` (
  `id_usuario` int(11) NOT NULL,
  `notificado` bit(1) DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `id` bigint(20) unsigned NOT NULL,
  `id_padre` int(11) DEFAULT '0',
  `nombre` varchar(45) NOT NULL,
  `descripcion` text
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `categoria`
--

INSERT INTO `categoria` (`id`, `id_padre`, `nombre`, `descripcion`) VALUES
(7, 10, 'Lenguajes de Programación', 'Tecnologías de desarrollo'),
(8, 7, 'ASP.NET', ''),
(9, 7, 'PHP', ''),
(10, 0, 'Desarrollo de Software', 'Software Development'),
(11, 10, 'Ingeniería de Software', ''),
(12, 11, 'RUP', ''),
(14, 10, 'Bases de Datos', ''),
(15, 14, 'SQL Server', ''),
(16, 14, 'Oracle', ''),
(17, 14, 'MySQL', ''),
(18, 14, 'PostgreSQL', ''),
(19, 0, 'Idiomas', ''),
(20, 19, 'Inglés', ''),
(21, 19, 'Francés', ''),
(22, 19, 'Alemán', ''),
(23, 19, 'Portugués', ''),
(24, 19, 'Italiano', ''),
(25, 19, 'Latín', ''),
(26, 19, 'Griego', ''),
(27, 14, 'MongoDB', ''),
(28, 0, 'Diseño Gráfico', '');

--
-- Disparadores `categoria`
--
DELIMITER $$
CREATE TRIGGER `tr_categoria_id_padre` BEFORE INSERT ON `categoria`
 FOR EACH ROW IF NEW.ID_PADRE IS NULL THEN
  SET NEW.ID_PADRE = 0;
END IF
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `categorias_populares`
--
CREATE TABLE IF NOT EXISTS `categorias_populares` (
`ID_CATEGORIA` bigint(20) unsigned
,`CATEGORIA` varchar(45)
,`CURSOS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `cursos_populares`
--
CREATE TABLE IF NOT EXISTS `cursos_populares` (
`ID_PRODUCTO` bigint(20) unsigned
,`CURSO` varchar(100)
,`COMPRAS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso_abonado`
--

CREATE TABLE IF NOT EXISTS `curso_abonado` (
  `id` bigint(20) unsigned NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_producto` bigint(20) unsigned NOT NULL,
  `comision` int(11) NOT NULL DEFAULT '0',
  `referido_por` int(11) DEFAULT NULL,
  `bono_solic` bit(1) DEFAULT b'0',
  `activo` bit(1) NOT NULL DEFAULT b'1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Disparadores `curso_abonado`
--
DELIMITER $$
CREATE TRIGGER `tr_act_cajas` AFTER INSERT ON `curso_abonado`
 FOR EACH ROW BEGIN
  DECLARE vPRIMER_USUARIO INT(11) DEFAULT NULL;
  DECLARE vCANT INT(11) DEFAULT NULL;
  
  IF ISNULL(NEW.REFERIDO_POR) THEN
    SELECT COUNT(*) INTO vCANT FROM `curso_abonado` WHERE REFERIDO_POR = NEW.ID_USUARIO;
    IF vCANT > 1 THEN
      SELECT ID_USUARIO INTO vPRIMER_USUARIO FROM `caja_1` ORDER BY FECHA LIMIT 1;
      IF COALESCE(vPRIMER_USUARIO, 0) <> 0 THEN
        CALL PROC_INS_caja_1(vPRIMER_USUARIO, NEW.ID_USUARIO);
      END IF;
    END IF;
  END IF;
  
  CALL PROC_ACT_caja_1;
  CALL PROC_ACT_caja_2;
  CALL PROC_ACT_caja_3;
  CALL PROC_ACT_caja_4;
  CALL PROC_ACT_caja_5;
  
  
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tr_act_valores` BEFORE INSERT ON `curso_abonado`
 FOR EACH ROW BEGIN
    DECLARE vREFERIDO INT(11) DEFAULT 0;
    DECLARE vCOMISION INT(11) DEFAULT 0;
    
    
    SET NEW.BONO_SOLIC = CASE WHEN ISNULL(NEW.BONO_SOLIC) THEN 0 ELSE NEW.BONO_SOLIC END;
    SELECT REFERIDO_POR INTO vREFERIDO FROM `user` WHERE ID = NEW.ID_USUARIO;
    SELECT PRECIO / 2 INTO vCOMISION FROM `producto` WHERE ID = NEW.ID_PRODUCTO;
    SET NEW.REFERIDO_POR = vREFERIDO;
	SET NEW.COMISION = vCOMISION;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1442697348),
('m130524_201442_init', 1442697351),
('m150926_233443_add_intentos_fallidos_to_user', 1443310626),
('m150926_233924_add_int_fall_to_user', 1443310780);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `munic`
--
CREATE TABLE IF NOT EXISTS `munic` (
`NOMBRE` varchar(75)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `nivel_acceso`
--

CREATE TABLE IF NOT EXISTS `nivel_acceso` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `operacion`
--

CREATE TABLE IF NOT EXISTS `operacion` (
  `id` int(11) NOT NULL,
  `nombre` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `ruta` varchar(128) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `operacion`
--

INSERT INTO `operacion` (`id`, `nombre`, `ruta`) VALUES
(1, 'Mostrar página "Acerca de"', 'site/about'),
(2, 'Mostrar página principal del sitio', 'site/index'),
(3, 'Mostrar detalles del curso', 'producto/view'),
(4, 'Subir ficheros al curso', 'producto/gestionar-ficheros'),
(5, 'Adicionar nuevo curso', 'producto/create'),
(6, 'Editar curso', 'producto/update'),
(7, 'Eliminar curso', 'producto/delete'),
(8, 'Listar cursos', 'producto/index'),
(9, 'Crear carpeta en curso', 'producto/crear-carpeta'),
(10, 'Eliminar ficheros del curso', 'producto/eliminar-fichero'),
(11, 'Eliminar carpeta del curso', 'producto/eliminar-carpeta'),
(12, 'Crear usuario', 'user/create'),
(13, 'Listar usuarios', 'user/index'),
(14, 'Descargar ficheros', 'producto/descargar'),
(31, 'Auditoría - Listar objetos', 'auditoria/index'),
(32, 'Auditoría - Mostrar detalles', 'auditoria/view'),
(33, 'Actualizar pagos', 'pagos/update'),
(34, 'Cambiar contraseña', 'site/change-password'),
(35, 'Enviar invitación', 'site/invitar');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE IF NOT EXISTS `pagos` (
  `id` bigint(20) unsigned NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `cantidad` double NOT NULL DEFAULT '0',
  `tipo` int(1) NOT NULL,
  `pagado` bit(1) NOT NULL DEFAULT b'0',
  `pagado_por` int(11) DEFAULT NULL,
  `fecha_solic` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `fecha_pagado` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Disparadores `pagos`
--
DELIMITER $$
CREATE TRIGGER `tr_pagos_fecha` BEFORE UPDATE ON `pagos`
 FOR EACH ROW BEGIN

  /*SET NEW.ID_USUARIO = OLD.ID_USUARIO;
  SET NEW.CANTIDAD = OLD.CANTIDAD;
  SET NEW.TIPO = OLD.TIPO;
  SET NEW.PAGADO_POR = OLD.PAGADO_POR;
  SET NEW.FECHA_SOLIC = OLD.FECHA_SOLIC;*/
  
  IF NEW.PAGADO = 1 THEN
   	SET NEW.FECHA_PAGADO = CURRENT_TIMESTAMP;
    IF NEW.TIPO = 1 THEN
      UPDATE USER SET CREDITO_COMISIONES = CREDITO_COMISIONES + NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
      UPDATE USER_HISTORIAL SET CREDITO_COMISIONES = CREDITO_COMISIONES + NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
    ELSE
      UPDATE USER SET CREDITO_CIRCUITOS = CREDITO_CIRCUITOS + NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
      UPDATE USER_HISTORIAL SET CREDITO_CIRCUITOS = CREDITO_CIRCUITOS + NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
    END IF;
  ELSE
    SET NEW.FECHA_PAGADO = NULL;
    IF NEW.TIPO = 1 THEN
      UPDATE USER SET CREDITO_COMISIONES = CREDITO_COMISIONES - NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
      UPDATE USER_HISTORIAL SET CREDITO_COMISIONES = CREDITO_COMISIONES - NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
    ELSE
      UPDATE USER SET CREDITO_CIRCUITOS = CREDITO_CIRCUITOS - NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
      UPDATE USER_HISTORIAL SET CREDITO_CIRCUITOS = CREDITO_CIRCUITOS - NEW.CANTIDAD WHERE ID = NEW.ID_USUARIO;
    END IF;
  END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pais`
--

CREATE TABLE IF NOT EXISTS `pais` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(75) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `pais`
--

INSERT INTO `pais` (`id`, `nombre`) VALUES
(1, 'Afganistán'),
(2, 'Albania'),
(3, 'Alemania'),
(4, 'Angola'),
(5, 'Antigua y Barbuda'),
(6, 'Arabia Saudita'),
(7, 'Argelia'),
(8, 'Argentina'),
(9, 'Armenia'),
(10, 'Australia'),
(11, 'Austria'),
(12, 'Azerbayán'),
(13, 'Bahamas'),
(14, 'Bahrein'),
(15, 'Bangladesh'),
(16, 'Barbados'),
(17, 'Belarús'),
(18, 'Bélgica'),
(19, 'Belice'),
(20, 'Benin'),
(21, 'Bolivia'),
(22, 'Bosnia Herzegovina'),
(23, 'Botswana'),
(24, 'Brasil'),
(25, 'Brunei Darussalam'),
(26, 'Bulgaria'),
(27, 'Burkina Faso'),
(28, 'Burundi'),
(29, 'Buthán'),
(30, 'Cabo Verde'),
(31, 'Cambodia'),
(32, 'Camerún'),
(33, 'Canadá'),
(34, 'Chad'),
(35, 'Chile'),
(36, 'China'),
(37, 'Chipre'),
(38, 'Colombia'),
(39, 'Comoras'),
(40, 'Congo'),
(41, 'Corea del Sur'),
(42, 'Costa de Marfil'),
(43, 'Costa Rica'),
(44, 'Croacia'),
(45, 'Cuba'),
(46, 'Dinamarca'),
(47, 'Djibouti'),
(48, 'Dominica'),
(49, 'Ecuador'),
(50, 'Egipto'),
(51, 'El Salvador'),
(52, 'Emiratos Árabes'),
(53, 'Escocia'),
(54, 'Eslovenia'),
(55, 'España'),
(56, 'Estados Unidos'),
(57, 'Estonia'),
(58, 'Etiopía'),
(59, 'Fiji'),
(60, 'Finlandia'),
(61, 'Francia'),
(62, 'Gabón'),
(63, 'Gales'),
(64, 'Gambia'),
(65, 'Georgia'),
(66, 'Ghana'),
(67, 'Granada'),
(68, 'Grecia'),
(69, 'Guatemala'),
(70, 'Guinea'),
(71, 'Guinea Bissau'),
(72, 'Guinea Ecuatorial'),
(73, 'Guyana'),
(74, 'Haití'),
(75, 'Holanda'),
(76, 'Honduras'),
(77, 'Hungría'),
(78, 'India'),
(79, 'Indonesia'),
(80, 'Inglaterra'),
(81, 'Iraq'),
(82, 'Irlanda'),
(83, 'Islandia'),
(84, 'Islas Maldivas'),
(85, 'Islas Marshall'),
(86, 'Islas Salomon'),
(87, 'Islas Seychelles'),
(88, 'Israel'),
(89, 'Italia'),
(90, 'Jamaica'),
(91, 'Japón'),
(92, 'Jordania'),
(93, 'Kazajstán'),
(94, 'Kenya'),
(95, 'Kirguistán'),
(96, 'Kuwait'),
(97, 'Laos'),
(98, 'Leshoto'),
(99, 'Letonia'),
(100, 'Líbano'),
(101, 'Liberia'),
(102, 'Libia'),
(103, 'Liechtenstein'),
(104, 'Lituania'),
(105, 'Luxemburgo'),
(106, 'Madagascar'),
(107, 'Malasia'),
(108, 'Malawi'),
(109, 'Mali'),
(110, 'Malta'),
(111, 'Marruecos'),
(112, 'Mauritania'),
(113, 'México'),
(114, 'Mongolia'),
(115, 'Montenegro'),
(116, 'Mozambique'),
(117, 'Namibia'),
(118, 'Nepal'),
(119, 'Nicaragua'),
(120, 'Níger'),
(121, 'Nigeria'),
(122, 'Noruega'),
(123, 'Nueva Zelandia'),
(124, 'Omán'),
(125, 'Pakistán'),
(126, 'Palestina'),
(127, 'Panamá'),
(128, 'Papúa Nueva Guinea'),
(129, 'Paraguay'),
(130, 'Perú'),
(131, 'Polonia'),
(132, 'Portugal'),
(133, 'Qatar'),
(134, 'Rep. Democr. Congo'),
(135, 'Rep. Dominicana'),
(136, 'Rep. Islámica Irán'),
(137, 'Rep. Pop. Dem. Corea'),
(138, 'República Checa'),
(139, 'República Serbia'),
(140, 'Rumanía'),
(141, 'Rusia'),
(142, 'Rwanda'),
(143, 'S. Vicente-Granadin'),
(144, 'Santa Lucía'),
(145, 'Senegal'),
(146, 'Sierra Leona'),
(147, 'Singapur'),
(148, 'Siria'),
(149, 'Somalia'),
(150, 'Sri Lanka'),
(151, 'Sudáfrica'),
(152, 'Sudán'),
(153, 'Suecia'),
(154, 'Suiza'),
(155, 'Suriname'),
(156, 'Swazilandia'),
(157, 'Tanzania'),
(158, 'Tayikistán'),
(159, 'Thailandia'),
(160, 'Togo'),
(161, 'Trinidad Tobago'),
(162, 'Túnez'),
(163, 'Turkmenistán'),
(164, 'Turquía'),
(165, 'Ucrania'),
(166, 'Uganda'),
(167, 'Uruguay'),
(168, 'Uzbekistán'),
(169, 'Vanuato'),
(170, 'Venezuela'),
(171, 'Viet Nam'),
(172, 'Yemen'),
(173, 'Yugoslavia'),
(174, 'Zambia'),
(175, 'Zimbabwe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `producto`
--

CREATE TABLE IF NOT EXISTS `producto` (
  `id` bigint(20) unsigned NOT NULL,
  `id_categoria` bigint(20) unsigned NOT NULL DEFAULT '0',
  `nombre` varchar(100) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `ruta_imagen` varchar(50) DEFAULT NULL,
  `precio` float NOT NULL,
  `rebaja` float DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;


-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `prov`
--
CREATE TABLE IF NOT EXISTS `prov` (
`NOMBRE` varchar(75)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol`
--

CREATE TABLE IF NOT EXISTS `rol` (
  `id` int(11) NOT NULL,
  `nombre` varchar(32) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `rol`
--

INSERT INTO `rol` (`id`, `nombre`) VALUES
(3, 'Administrador'),
(2, 'Asesor'),
(1, 'Cliente'),
(4, 'Super administrador');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rol_operacion`
--

CREATE TABLE IF NOT EXISTS `rol_operacion` (
  `rol_id` int(11) NOT NULL,
  `operacion_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `rol_operacion`
--

INSERT INTO `rol_operacion` (`rol_id`, `operacion_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(1, 2),
(2, 2),
(3, 2),
(2, 3),
(3, 3),
(3, 4),
(3, 5),
(3, 6),
(3, 7),
(1, 8),
(2, 8),
(3, 8),
(3, 9),
(3, 10),
(3, 11),
(1, 13),
(2, 13),
(3, 13),
(1, 14),
(2, 14),
(3, 14),
(1, 34),
(2, 34),
(3, 34),
(1, 35);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_doc_id`
--

CREATE TABLE IF NOT EXISTS `tipo_doc_id` (
  `id` bigint(20) unsigned NOT NULL,
  `nombre` varchar(25) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `tipo_doc_id`
--

INSERT INTO `tipo_doc_id` (`id`, `nombre`) VALUES
(1, 'DNI'),
(2, 'NIE'),
(3, 'Pasaporte');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `rol_id` int(11) NOT NULL DEFAULT '10',
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `id_tipo_doc_id` bigint(20) unsigned NOT NULL,
  `num_doc_id` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `tel_movil` bigint(20) NOT NULL,
  `tel_fijo` bigint(20) DEFAULT NULL,
  `skype` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paypal` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `facebook` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkedin` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `munic` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `prov` varchar(75) COLLATE utf8_unicode_ci NOT NULL,
  `id_pais` bigint(20) unsigned NOT NULL,
  `referido_por` int(11) DEFAULT NULL,
  `term_condic` bit(1) NOT NULL DEFAULT b'0',
  `id_nivel_acceso` bigint(20) unsigned DEFAULT NULL,
  `idioma` varchar(7) COLLATE utf8_unicode_ci DEFAULT 'es-ES',
  `intentos_cnx_fallidos` smallint(1) DEFAULT '0',
  `credito_circuitos` double NOT NULL DEFAULT '0',
  `credito_comisiones` double NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=547 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `rol_id`, `nombre`, `apellidos`, `id_tipo_doc_id`, `num_doc_id`, `tel_movil`, `tel_fijo`, `skype`, `paypal`, `facebook`, `linkedin`, `twitter`, `youtube`, `direccion`, `codigo_postal`, `munic`, `prov`, `id_pais`, `referido_por`, `term_condic`, `id_nivel_acceso`, `idioma`, `intentos_cnx_fallidos`, `credito_circuitos`, `credito_comisiones`, `created_at`, `updated_at`) VALUES
(546, 'admin', 'wow8iniTqVaEGCREc-UYt3ZeD6O7rP8f', '$2y$13$0xze0zqAv8K/O.W7C5lvNufZXEgTaOqBwh41z//6OlxkQCxETOJcW', NULL, 'admin@siitur.com', 1, 4, 'Administrador', 'Poderoso', 1, '123', 312, 123, '', 'admin@siitur.com', '', '', '', '', 'Calle 23 e/ L y M', '123', 'Vallecas', 'Madrid', 55, NULL, b'1', NULL, 'es-ES', 0, 0, 0, 1448351836, 1448352401);

--
-- Disparadores `user`
--
DELIMITER $$
CREATE TRIGGER `tr_act_usuario` BEFORE UPDATE ON `user`
 FOR EACH ROW BEGIN
    IF NEW.INTENTOS_CNX_FALLIDOS > 2 THEN
        SET NEW.STATUS = 2;
        SET NEW.PROV = TRIM(NEW.PROV);
        SET NEW.MUNIC = TRIM(NEW.MUNIC);
        SET NEW.INTENTOS_CNX_FALLIDOS = 3;
    END IF;

    SET NEW.CREDITO_CIRCUITOS = COALESCE(NEW.CREDITO_CIRCUITOS, 0);
    SET NEW.CREDITO_COMISIONES = COALESCE(NEW.CREDITO_COMISIONES, 0);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_historial`
--

CREATE TABLE IF NOT EXISTS `user_historial` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '0',
  `rol_id` int(11) NOT NULL DEFAULT '10',
  `nombre` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `id_tipo_doc_id` bigint(20) unsigned NOT NULL,
  `num_doc_id` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  `tel_movil` bigint(20) DEFAULT NULL,
  `tel_fijo` bigint(20) DEFAULT NULL,
  `skype` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `paypal` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `facebook` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `linkedin` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `twitter` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `youtube` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `codigo_postal` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_munic` bigint(20) unsigned DEFAULT NULL,
  `id_prov` bigint(20) unsigned DEFAULT NULL,
  `id_pais` bigint(20) unsigned NOT NULL,
  `referido_por` int(11) DEFAULT NULL,
  `term_condic` bit(1) NOT NULL DEFAULT b'0',
  `id_nivel_acceso` bigint(20) unsigned DEFAULT NULL,
  `idioma` varchar(7) COLLATE utf8_unicode_ci DEFAULT 'en-US',
  `intentos_cnx_fallidos` smallint(1) DEFAULT '0',
  `credito_circuitos` double NOT NULL DEFAULT '0',
  `credito_comisiones` double NOT NULL DEFAULT '0',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_caja_1`
--
CREATE TABLE IF NOT EXISTS `usuarios_caja_1` (
`ID_USUARIO` int(11)
,`INVITADOS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_caja_2`
--
CREATE TABLE IF NOT EXISTS `usuarios_caja_2` (
`ID_USUARIO` int(11)
,`INVITADOS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_caja_3`
--
CREATE TABLE IF NOT EXISTS `usuarios_caja_3` (
`ID_USUARIO` int(11)
,`INVITADOS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_caja_4`
--
CREATE TABLE IF NOT EXISTS `usuarios_caja_4` (
`ID_USUARIO` int(11)
,`INVITADOS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_compras_ventas`
--
CREATE TABLE IF NOT EXISTS `usuarios_compras_ventas` (
`ID_USUARIO` int(11)
,`COMPRAS` bigint(21)
,`VENTAS` bigint(21)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuarios_pagos`
--
CREATE TABLE IF NOT EXISTS `usuarios_pagos` (
`id_usuario` int(11)
,`pend_venta_directa` double
,`pend_circuito` double
,`efect_venta_directa` double
,`efect_circuito` double
,`solicitables_venta_directa` decimal(32,0)
,`solicitables_circuito` int(4)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_invitado`
--
CREATE TABLE IF NOT EXISTS `usuario_invitado` (
`id_usuario` int(11)
,`id_invitado` int(11)
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_invitados_caja_1`
--
CREATE TABLE IF NOT EXISTS `usuario_invitados_caja_1` (
`ID_USUARIO` int(11)
,`ID_INVITADO` int(11)
,`INVITADO` varchar(151)
,`FECHA` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_invitados_caja_2`
--
CREATE TABLE IF NOT EXISTS `usuario_invitados_caja_2` (
`ID_USUARIO` int(11)
,`ID_INVITADO` int(11)
,`INVITADO` varchar(151)
,`FECHA` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_invitados_caja_3`
--
CREATE TABLE IF NOT EXISTS `usuario_invitados_caja_3` (
`ID_USUARIO` int(11)
,`ID_INVITADO` int(11)
,`INVITADO` varchar(151)
,`FECHA` timestamp
);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `usuario_invitados_caja_4`
--
CREATE TABLE IF NOT EXISTS `usuario_invitados_caja_4` (
`ID_USUARIO` int(11)
,`ID_INVITADO` int(11)
,`INVITADO` varchar(151)
,`FECHA` timestamp
);

-- --------------------------------------------------------

--
-- Estructura para la vista `categorias_populares`
--
DROP TABLE IF EXISTS `categorias_populares`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `categorias_populares` AS select `p`.`id_categoria` AS `ID_CATEGORIA`,`c`.`nombre` AS `CATEGORIA`,count(`p`.`id_categoria`) AS `CURSOS` from (`producto` `p` join `categoria` `c`) where (`p`.`id_categoria` = `c`.`id`) group by `p`.`id_categoria` order by count(`p`.`id_categoria`) desc,`c`.`nombre` limit 10;

-- --------------------------------------------------------

--
-- Estructura para la vista `cursos_populares`
--
DROP TABLE IF EXISTS `cursos_populares`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `cursos_populares` AS select `ca`.`id_producto` AS `ID_PRODUCTO`,`p`.`nombre` AS `CURSO`,count(`ca`.`id_producto`) AS `COMPRAS` from (`producto` `p` join `curso_abonado` `ca`) where (`p`.`id` = `ca`.`id_producto`) group by `ca`.`id_producto` order by count(`ca`.`id_producto`) desc,`p`.`nombre` limit 10;

-- --------------------------------------------------------

--
-- Estructura para la vista `munic`
--
DROP TABLE IF EXISTS `munic`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `munic` AS select distinct trim(`user`.`munic`) AS `NOMBRE` from `user`;

-- --------------------------------------------------------

--
-- Estructura para la vista `prov`
--
DROP TABLE IF EXISTS `prov`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `prov` AS select distinct trim(`user`.`prov`) AS `NOMBRE` from `user`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_caja_1`
--
DROP TABLE IF EXISTS `usuarios_caja_1`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_caja_1` AS select `ca`.`id_usuario` AS `ID_USUARIO`,(select count(0) from `caja_1` where `caja_1`.`id_usuario` in (select `user`.`id` from `user` where (`user`.`referido_por` = `ca`.`id_usuario`))) AS `INVITADOS` from `caja_1` `ca` group by `ca`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_caja_2`
--
DROP TABLE IF EXISTS `usuarios_caja_2`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_caja_2` AS select `ca`.`id_usuario` AS `ID_USUARIO`,(select count(0) from `caja_2` where `caja_2`.`id_usuario` in (select `user`.`id` from `user` where (`user`.`referido_por` = `ca`.`id_usuario`))) AS `INVITADOS` from `caja_2` `ca` group by `ca`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_caja_3`
--
DROP TABLE IF EXISTS `usuarios_caja_3`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_caja_3` AS select `ca`.`id_usuario` AS `ID_USUARIO`,(select count(0) from `caja_3` where `caja_3`.`id_usuario` in (select `user`.`id` from `user` where (`user`.`referido_por` = `ca`.`id_usuario`))) AS `INVITADOS` from `caja_3` `ca` group by `ca`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_caja_4`
--
DROP TABLE IF EXISTS `usuarios_caja_4`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_caja_4` AS select `ca`.`id_usuario` AS `ID_USUARIO`,(select count(0) from `caja_4` where `caja_4`.`id_usuario` in (select `user`.`id` from `user` where (`user`.`referido_por` = `ca`.`id_usuario`))) AS `INVITADOS` from `caja_4` `ca` group by `ca`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_compras_ventas`
--
DROP TABLE IF EXISTS `usuarios_compras_ventas`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_compras_ventas` AS select `ca`.`id_usuario` AS `ID_USUARIO`,count(`ca`.`id_usuario`) AS `COMPRAS`,(select count(0) from `curso_abonado` where ((`curso_abonado`.`referido_por` = `ca`.`id_usuario`) and (`curso_abonado`.`activo` = 1))) AS `VENTAS` from `curso_abonado` `ca` group by `ca`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuarios_pagos`
--
DROP TABLE IF EXISTS `usuarios_pagos`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuarios_pagos` AS select `p`.`id_usuario` AS `id_usuario`,sum((case when ((`p`.`tipo` = 1) and (`p`.`pagado` = 0)) then `p`.`cantidad` else 0 end)) AS `pend_venta_directa`,sum((case when ((`p`.`tipo` = 2) and (`p`.`pagado` = 0)) then `p`.`cantidad` else 0 end)) AS `pend_circuito`,sum((case when ((`p`.`tipo` = 1) and (`p`.`pagado` = 1)) then `p`.`cantidad` else 0 end)) AS `efect_venta_directa`,sum((case when ((`p`.`tipo` = 2) and (`p`.`pagado` = 1)) then `p`.`cantidad` else 0 end)) AS `efect_circuito`,(select coalesce(sum(`curso_abonado`.`comision`),0) from `curso_abonado` where ((`curso_abonado`.`referido_por` = `p`.`id_usuario`) and (`curso_abonado`.`bono_solic` = 0) and (`curso_abonado`.`activo` = 1))) AS `solicitables_venta_directa`,coalesce((select 3000 from `caja_5` where (`caja_5`.`id_usuario` = `p`.`id_usuario`)),0) AS `solicitables_circuito` from `pagos` `p` group by `p`.`id_usuario`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_invitado`
--
DROP TABLE IF EXISTS `usuario_invitado`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuario_invitado` AS select `u1`.`id` AS `id_usuario`,`u2`.`id` AS `id_invitado` from (`user` `u1` join `user` `u2`) where (`u1`.`id` = `u2`.`referido_por`) order by `u1`.`id`,`u2`.`id`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_invitados_caja_1`
--
DROP TABLE IF EXISTS `usuario_invitados_caja_1`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuario_invitados_caja_1` AS select `c`.`id_usuario` AS `ID_USUARIO`,`c`.`id_invitado` AS `ID_INVITADO`,(select concat(`user`.`nombre`,' ',`user`.`apellidos`) from `user` where (`user`.`id` = (case when (`c`.`id_invitado` = 0) then `c`.`id_usuario` else `c`.`id_invitado` end))) AS `INVITADO`,`c`.`fecha` AS `FECHA` from `caja_1` `c` order by `c`.`fecha`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_invitados_caja_2`
--
DROP TABLE IF EXISTS `usuario_invitados_caja_2`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuario_invitados_caja_2` AS select `c`.`id_usuario` AS `ID_USUARIO`,`c`.`id_invitado` AS `ID_INVITADO`,(select concat(`user`.`nombre`,' ',`user`.`apellidos`) from `user` where (`user`.`id` = (case when (`c`.`id_invitado` = 0) then `c`.`id_usuario` else `c`.`id_invitado` end))) AS `INVITADO`,`c`.`fecha` AS `FECHA` from `caja_2` `c` order by `c`.`fecha`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_invitados_caja_3`
--
DROP TABLE IF EXISTS `usuario_invitados_caja_3`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuario_invitados_caja_3` AS select `c`.`id_usuario` AS `ID_USUARIO`,`c`.`id_invitado` AS `ID_INVITADO`,(select concat(`user`.`nombre`,' ',`user`.`apellidos`) from `user` where (`user`.`id` = (case when (`c`.`id_invitado` = 0) then `c`.`id_usuario` else `c`.`id_invitado` end))) AS `INVITADO`,`c`.`fecha` AS `FECHA` from `caja_3` `c` order by `c`.`fecha`;

-- --------------------------------------------------------

--
-- Estructura para la vista `usuario_invitados_caja_4`
--
DROP TABLE IF EXISTS `usuario_invitados_caja_4`;

CREATE ALGORITHM=UNDEFINED SQL SECURITY DEFINER VIEW `usuario_invitados_caja_4` AS select `c`.`id_usuario` AS `ID_USUARIO`,`c`.`id_invitado` AS `ID_INVITADO`,(select concat(`user`.`nombre`,' ',`user`.`apellidos`) from `user` where (`user`.`id` = (case when (`c`.`id_invitado` = 0) then `c`.`id_usuario` else `c`.`id_invitado` end))) AS `INVITADO`,`c`.`fecha` AS `FECHA` from `caja_4` `c` order by `c`.`fecha`;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `app_config`
--
ALTER TABLE `app_config`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_operacion` (`operacion`),
  ADD KEY `autor` (`autor`);

--
-- Indices de la tabla `caja_1`
--
ALTER TABLE `caja_1`
  ADD PRIMARY KEY (`id_usuario`,`id_invitado`),
  ADD KEY `id_invitado` (`id_invitado`),
  ADD KEY `fecha` (`fecha`);

--
-- Indices de la tabla `caja_2`
--
ALTER TABLE `caja_2`
  ADD PRIMARY KEY (`id_usuario`,`id_invitado`),
  ADD KEY `id_invitado` (`id_invitado`),
  ADD KEY `fecha` (`fecha`);

--
-- Indices de la tabla `caja_3`
--
ALTER TABLE `caja_3`
  ADD PRIMARY KEY (`id_usuario`,`id_invitado`),
  ADD KEY `id_invitado` (`id_invitado`),
  ADD KEY `fecha` (`fecha`);

--
-- Indices de la tabla `caja_4`
--
ALTER TABLE `caja_4`
  ADD PRIMARY KEY (`id_usuario`,`id_invitado`),
  ADD KEY `id_invitado` (`id_invitado`),
  ADD KEY `fecha` (`fecha`);

--
-- Indices de la tabla `caja_5`
--
ALTER TABLE `caja_5`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `notificado` (`notificado`);

--
-- Indices de la tabla `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `id_padre_nombre` (`id_padre`,`nombre`) USING BTREE;

--
-- Indices de la tabla `curso_abonado`
--
ALTER TABLE `curso_abonado`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_usuario_producto` (`id_usuario`,`id_producto`) USING BTREE,
  ADD KEY `referido_por` (`referido_por`),
  ADD KEY `id_producto` (`id_producto`) USING BTREE,
  ADD KEY `activo` (`activo`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `bono_solic` (`bono_solic`) USING BTREE;

--
-- Indices de la tabla `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indices de la tabla `nivel_acceso`
--
ALTER TABLE `nivel_acceso`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `operacion`
--
ALTER TABLE `operacion`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `ruta_2` (`ruta`),
  ADD KEY `ruta` (`ruta`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `pagado` (`pagado`),
  ADD KEY `tipo` (`tipo`),
  ADD KEY `pagado_por` (`pagado_por`);

--
-- Indices de la tabla `pais`
--
ALTER TABLE `pais`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `ind_prod_cat` (`id_categoria`);

--
-- Indices de la tabla `rol`
--
ALTER TABLE `rol`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nombre` (`nombre`);

--
-- Indices de la tabla `rol_operacion`
--
ALTER TABLE `rol_operacion`
  ADD PRIMARY KEY (`rol_id`,`operacion_id`),
  ADD KEY `operacion_id` (`operacion_id`);

--
-- Indices de la tabla `tipo_doc_id`
--
ALTER TABLE `tipo_doc_id`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indices de la tabla `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `ind_user_tipo_doc_pais` (`id_tipo_doc_id`,`num_doc_id`,`id_pais`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`),
  ADD KEY `id_nivel_acceso` (`id_nivel_acceso`),
  ADD KEY `id_munic` (`munic`),
  ADD KEY `id_prov` (`prov`),
  ADD KEY `id_pais` (`id_pais`),
  ADD KEY `id_tipo_doc_id` (`id_tipo_doc_id`),
  ADD KEY `rol_id` (`rol_id`),
  ADD KEY `referido_por` (`referido_por`);

--
-- Indices de la tabla `user_historial`
--
ALTER TABLE `user_historial`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `app_config`
--
ALTER TABLE `app_config`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `auditoria`
--
ALTER TABLE `auditoria`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT de la tabla `curso_abonado`
--
ALTER TABLE `curso_abonado`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `nivel_acceso`
--
ALTER TABLE `nivel_acceso`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `operacion`
--
ALTER TABLE `operacion`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- AUTO_INCREMENT de la tabla `pagos`
--
ALTER TABLE `pagos`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT de la tabla `pais`
--
ALTER TABLE `pais`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=176;
--
-- AUTO_INCREMENT de la tabla `producto`
--
ALTER TABLE `producto`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `rol`
--
ALTER TABLE `rol`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT de la tabla `tipo_doc_id`
--
ALTER TABLE `tipo_doc_id`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=547;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `caja_1`
--
ALTER TABLE `caja_1`
  ADD CONSTRAINT `caja_1_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `caja_2`
--
ALTER TABLE `caja_2`
  ADD CONSTRAINT `caja_2_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `caja_3`
--
ALTER TABLE `caja_3`
  ADD CONSTRAINT `caja_3_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `caja_4`
--
ALTER TABLE `caja_4`
  ADD CONSTRAINT `caja_4_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `caja_5`
--
ALTER TABLE `caja_5`
  ADD CONSTRAINT `caja_5_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `curso_abonado`
--
ALTER TABLE `curso_abonado`
  ADD CONSTRAINT `curso_abonado_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `curso_abonado_ibfk_3` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`pagado_por`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Filtros para la tabla `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id`) ON UPDATE CASCADE;

--
-- Filtros para la tabla `rol_operacion`
--
ALTER TABLE `rol_operacion`
  ADD CONSTRAINT `rol_operacion_ibfk_1` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `rol_operacion_ibfk_2` FOREIGN KEY (`operacion_id`) REFERENCES `operacion` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_10` FOREIGN KEY (`referido_por`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_5` FOREIGN KEY (`id_tipo_doc_id`) REFERENCES `tipo_doc_id` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_6` FOREIGN KEY (`rol_id`) REFERENCES `rol` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `user_ibfk_9` FOREIGN KEY (`id_pais`) REFERENCES `pais` (`id`) ON UPDATE CASCADE;



-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `textos_interfaz`
--

CREATE TABLE IF NOT EXISTS `textos_interfaz` (
  `id` bigint(20) unsigned NOT NULL,
  `titulo_es` varchar(50) NOT NULL,
  `titulo_en` varchar(50) NOT NULL,
  `titulo_fr` varchar(50) NOT NULL,
  `titulo_pt` varchar(50) NOT NULL,
  `contenido_es` varchar(2000) NOT NULL,
  `contenido_en` varchar(2000) NOT NULL,
  `contenido_fr` varchar(2000) NOT NULL,
  `contenido_pt` varchar(2000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `textos_interfaz`
--

INSERT INTO `textos_interfaz` (`id`, `titulo_es`, `titulo_en`, `titulo_fr`, `titulo_pt`, `contenido_es`, `contenido_en`, `contenido_fr`, `contenido_pt`) VALUES
(1, 'Acerca de', 'About', 'À propos de', 'Acerca do', 'PonderNET es una comunidad online destinada a la formación no reglada. Se trata de una plataforma de compra-venta de diferentes cursos formativos: toda una serie de herramientas y productos digitales que buscan acercar a las personas al éxito.\r\n\r\nAl mismo tiempo que el usuario se forma, tiene la posibilidad de afiliarse a nuestro sistema y formar parte de un negocio online lleno de oportunidades, que le permite mejorar su economía y su vida personal, ¡y todo a través del conocimiento! Ponder Net busca un equilibrio en la vida de las personas mediante una oferta formativa actualizada, haciendo uso de las últimas herramientas tecnológicas.\r\n\r\nPonder Net es la semilla de una familia mundial cuyo mejor valor es el aprendizaje y, a través de éste, es posible llegar a la prosperidad económica.\r\n\r\n¡Súmate a nosotros!\r\n', 'PonderNET is an online community focused on education. It''s a buy & sell platform with different educative resources: a complete set of digital tools and products to get people closer to success.While the user gets educated, he has the opportunity of joining our system and becoming a part of an online business full of opportunities, that allows him to increase his income and personal life.\r\n\r\nAnd everything comes through knowledge!PonderNET looks for a balance in people''s lives through an updated educational offer, making a good use of the latest technological tools. PonderNET is the seed of a worldwide family which most valuable asset is learning, which makes it possible to obtain economical prosperity.\r\n\r\nJoin us!', 'Ponder Net est une communauté online destinée à la formation. Elle est une plateforme pour l''achat et la vente de différents cours de formation: une gamme d''outils et produits digitaux qui approchent aux gents à obtenir le succès.\r\n\r\nAlors que la personne se forme, elle a la possibilité de se joindre à notre système et faire partie d''un affaire online plein d''oportunités, qui lui permet d''améliorer son économie et sa vie personnelle, et tout à travers la connaissance!\r\n\r\nPonder Net cherche un équilibre dans la vie des gens à travers d’une offert de formation actualisé, en utilisant les derniers outils technologiques. Ponder Net est la graine d''une famille mondiale dans la quelle son meilleur valeur est l''aprentissage et, à travers de celle ci, il est possible d''arriver à la prospérité économique.\r\n\r\nRejoignez-nous!', 'PonderNET pt'),
(2, 'Contacto', 'Contact', 'Contàct', 'Contact', 'Si tiene alguna inquietud o duda, utilice el siguiente formulario para contactarnos.\r\nGracias.', 'If you have business inquiries or other questions, please fill out the following form to contact us.\r\nThank you.', 'Lorem', 'Lorem pt');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `textos_interfaz`
--
ALTER TABLE `textos_interfaz`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `nombre` (`titulo_es`);

--
-- AUTO_INCREMENT de la tabla `textos_interfaz`
--
ALTER TABLE `textos_interfaz`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `diapos_carrusel`
--

CREATE TABLE IF NOT EXISTS `diapos_carrusel` (
  `id` bigint(20) unsigned NOT NULL,
  `ruta_imagen` varchar(150) DEFAULT NULL,
  `titulo_tam_fuente` int(2) DEFAULT NULL,
  `titulo_alineacion` varchar(10) NOT NULL,
  `titulo_en` varchar(250) DEFAULT NULL,
  `titulo_es` varchar(250) DEFAULT NULL,
  `titulo_fr` varchar(250) DEFAULT NULL,
  `titulo_pt` varchar(250) DEFAULT NULL,
  `descripcion_tam_fuente` int(2) NOT NULL,
  `descripcion_alineacion` varchar(10) DEFAULT NULL,
  `descripcion_en` varchar(500) DEFAULT NULL,
  `descripcion_es` varchar(500) DEFAULT NULL,
  `descripcion_fr` varchar(500) DEFAULT NULL,
  `descripcion_pt` varchar(500) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Indices de la tabla `diapos_carrusel`
--
ALTER TABLE `diapos_carrusel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT de la tabla `diapos_carrusel`
--
ALTER TABLE `diapos_carrusel`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
  
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
