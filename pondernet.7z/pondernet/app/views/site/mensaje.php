<?php

use app\controllers\SiteController;

/* @var $this yii\web\View */
/* @var $model app\models\Producto */

$this->params['breadcrumbs'][] = ['label' => SiteController::translate('Confirm registration')];
?>
<div class="producto-view">
    <?= \app\controllers\StaticMembers::MostrarMensajes() ?>
</div>
