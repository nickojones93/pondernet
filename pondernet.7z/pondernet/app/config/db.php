<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=db599094754',
    'username' => 'db599094754',
    'password' => 'db599094754',
    'charset' => 'utf8',
];
