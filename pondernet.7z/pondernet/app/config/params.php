<?php

return [
    'adminEmail' => 'pondernet@smtp.1and1.es',
];
